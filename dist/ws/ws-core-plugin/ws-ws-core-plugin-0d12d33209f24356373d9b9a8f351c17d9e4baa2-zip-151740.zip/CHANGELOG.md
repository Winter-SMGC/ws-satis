# Changelog

## [1.1.2](https://github.com/Winter-SMGC/ws-core-plugin/compare/v1.1.1...v1.1.2) (2026-04-08)


### Miscellaneous Chores

* add .gitattributes to ignore GitHub export ([c9e0585](https://github.com/Winter-SMGC/ws-core-plugin/commit/c9e0585f9e9e32ee09bd6506b3ca1a723166f1c7))

## [1.1.1](https://github.com/Winter-SMGC/ws-core-plugin/compare/v1.1.0...v1.1.1) (2026-04-07)


### Bug Fixes

* move publish process to release-please workflow ([#2](https://github.com/Winter-SMGC/ws-core-plugin/issues/2)) ([007ddaf](https://github.com/Winter-SMGC/ws-core-plugin/commit/007ddaf8a1accc82840871c60a660ea4abef666e))

## [1.1.0](https://github.com/Winter-SMGC/ws-core-plugin/compare/v1.0.0...v1.1.0) (2026-04-07)


### Features

* add changelog file ([c507b84](https://github.com/Winter-SMGC/ws-core-plugin/commit/c507b8481e371a01682830d6be05fd21bb4690a5))


### Miscellaneous Chores

* add editorconfig for code style ([347390a](https://github.com/Winter-SMGC/ws-core-plugin/commit/347390a8be45d8033857fd4b87d8840c85d1b5e8))
* **CI:** add Release Please ([baca128](https://github.com/Winter-SMGC/ws-core-plugin/commit/baca12862468e406ea9890566aacd1de5b68fee9))

## Changelog
