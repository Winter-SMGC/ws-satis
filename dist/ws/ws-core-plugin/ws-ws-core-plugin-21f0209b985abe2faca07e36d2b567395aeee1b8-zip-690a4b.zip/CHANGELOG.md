# Changelog

## [1.1.0](https://github.com/Winter-SMGC/ws-core-plugin/compare/v1.0.0...v1.1.0) (2026-04-07)


### Features

* add changelog file ([c507b84](https://github.com/Winter-SMGC/ws-core-plugin/commit/c507b8481e371a01682830d6be05fd21bb4690a5))


### Miscellaneous Chores

* add editorconfig for code style ([347390a](https://github.com/Winter-SMGC/ws-core-plugin/commit/347390a8be45d8033857fd4b87d8840c85d1b5e8))
* **CI:** add Release Please ([baca128](https://github.com/Winter-SMGC/ws-core-plugin/commit/baca12862468e406ea9890566aacd1de5b68fee9))

## Changelog
