<?php namespace Ws\Core\Updates;

use Seeder;
use System\Models\Parameter;

class SetDefaultTheme extends Seeder
{
    public function run()
    {
        Parameter::set('cms::theme.active', 'ws-theme');
    }
}
