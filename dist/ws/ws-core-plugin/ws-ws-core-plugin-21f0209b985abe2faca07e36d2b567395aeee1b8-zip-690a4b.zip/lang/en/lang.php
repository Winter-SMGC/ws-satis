<?php

return [
    'plugin' => [
        'name' => 'Core',
        'description' => 'No description provided yet...',
    ],
    'permissions' => [
        'some_permission' => 'Some permission',
    ],
];
