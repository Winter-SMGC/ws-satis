<?php

Route::get('/api', function () {
    return 'Hello World!!!!!!!!!!';
});
