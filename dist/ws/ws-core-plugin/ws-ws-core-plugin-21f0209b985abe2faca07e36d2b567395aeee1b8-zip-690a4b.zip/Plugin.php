<?php

namespace Ws\Core;

use Backend\Facades\Backend;
use Backend\Models\UserRole;
use System\Classes\PluginBase;

/**
 * Core Plugin Information File
 */
class Plugin extends PluginBase
{
    /**
     * Returns information about this plugin.
     */
    public function pluginDetails(): array
    {
        return [
            'name' => 'Winter SMGC Core System',
            'description' => 'Núcleo de configurações globais, skins e utilitários do Winter SMGC.',
            'author' => 'Winter SMGC',
            'icon' => 'icon-microchip',
        ];
    }

    /**
     * Register method, called when the plugin is first registered.
     */
    public function register(): void {}

    /**
     * Boot method, called right before the request route.
     */
    public function boot(): void {}

    /**
     * Registers any frontend components implemented in this plugin.
     */
    public function registerComponents(): array
    {
        return []; // Remove this line to activate
    }

    /**
     * Registers any backend permissions used by this plugin.
     */
    public function registerPermissions(): array
    {
        return []; // Remove this line to activate

        return [
            'wintersmgc.core.some_permission' => [
                'tab' => 'wintersmgc.core::lang.plugin.name',
                'label' => 'wintersmgc.core::lang.permissions.some_permission',
                'roles' => [UserRole::CODE_DEVELOPER, UserRole::CODE_PUBLISHER],
            ],
        ];
    }

    /**
     * Registers backend navigation items for this plugin.
     */
    public function registerNavigation(): array
    {
        return []; // Remove this line to activate

        return [
            'core' => [
                'label' => 'wintersmgc.core::lang.plugin.name',
                'url' => Backend::url('wintersmgc/core/mycontroller'),
                'icon' => 'icon-leaf',
                'permissions' => ['wintersmgc.core.*'],
                'order' => 500,
            ],
        ];
    }
}
