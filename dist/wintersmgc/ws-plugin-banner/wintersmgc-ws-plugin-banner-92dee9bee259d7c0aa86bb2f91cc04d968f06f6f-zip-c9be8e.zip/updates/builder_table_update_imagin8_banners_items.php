<?php namespace WinterSmgc\Banners\Updates;

use Schema;
use Winter\Storm\Database\Updates\Migration;

class BuilderTableUpdateWinterSmgcBannersItems extends Migration
{
    public function up()
    {
        Schema::table('wintersmgc_banners_items', function($table)
        {
            $table->integer('sort_order')->default(0)->change();
        });
    }
    
    public function down()
    {
        Schema::table('wintersmgc_banners_items', function($table)
        {
            $table->integer('sort_order')->default(null)->change();
        });
    }
}
