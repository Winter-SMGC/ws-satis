<?php namespace WinterSmgc\Banners\Updates;

use Schema;
use Winter\Storm\Database\Updates\Migration;

class BuilderTableUpdateWinterSmgcBannersItems2 extends Migration
{
    public function up()
    {
        Schema::table('wintersmgc_banners_items', function($table)
        {
            $table->boolean('is_active')->default(true)->change();
        });
    }
    
    public function down()
    {
        Schema::table('wintersmgc_banners_items', function($table)
        {
            $table->boolean('is_active')->default(null)->change();
        });
    }
}
