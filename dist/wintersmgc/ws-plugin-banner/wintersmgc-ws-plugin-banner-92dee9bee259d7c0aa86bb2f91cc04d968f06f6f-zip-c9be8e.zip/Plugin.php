<?php namespace WinterSmgc\Banners;

use System\Classes\PluginBase;

class Plugin extends PluginBase
{
    public function registerComponents()
    {
        return [
            'WinterSmgc\Banners\Components\BannerRender' => 'bannerRender',
        ];
    }

    public function registerSettings()
    {
    }
}
